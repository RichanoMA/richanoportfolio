
<?php include 'header.php'?>


    


<div class="sectie_main_1_5">
<ul>
    <li>
    Kies park <i class="fas fa-sort-down"></i>
    </li>
    <li>Aankomst/Vertrek<i class="fas fa-sort-down"></i></li>
    <li>Aantal personen<i class="fas fa-sort-down"></i></li>
    <li><a href='bungalows.php'>Zoeken</a></li>
    </ul>
</div>
<div class="sectie_main_2">

    
    <h1>UITGELICHT</h1>
    <p></p>
    <hr>
</div>
 <!--Sectie 1 -->
<div class="sectie_1">
    <div class="sectie_1_grid">
        
         <!--Het volgende stuk code zijn item blokjes voor de bungalows -->

<div class="item1"><img src="../IMG/bungalow3.jpg">
    <div class="itemtype">
        <p>BASIS</p>
       
    </div>
    <div class= "itemcontent">
     
        <ul>
        <li> PRIJS:<strong>€ 399,-</strong></li>
            <li> PLAATS: <strong>AMSTERDAM</strong></li>
            <li>Aantal personen: <strong>4</strong></li>
            <li>Aantal slaapkamers: <strong>3 </strong></li>
            <li>Terras</li>
            <li>Gratis wifi</li>
        </ul>
        <a href="bungalows.php">RESERVEER NU</a>
    </div>
    </div>
<div class="item1"><img src="../IMG/bungalow8.jpg">
    <div class="itemtype">
        <p>BASIS</p>
       
    </div>
    
    <div class= "itemcontent">
     
        <ul>
        <li> PRIJS:<strong>€ 399,-</strong></li>
            <li> PLAATS: <strong>AMSTERDAM</strong></li>
            <li>Aantal personen: <strong>4</strong></li>
            <li>Aantal slaapkamers: <strong>3 </strong></li>
            <li>Terras</li>
            <li>Gratis wifi</li>
        </ul>
        <a href="bungalows.php">RESERVEER NU</a>
    </div></div>
    
<div class="item1"><img src="../IMG/bungalow7.jpg">
    <div class="itemtype">
        <p>BASIS</p>
       
    </div>
    <div class= "itemcontent">
     
        <ul>
        <li> PRIJS:<strong>€ 399,-</strong></li>
            <li> PLAATS: <strong>AMSTERDAM</strong></li>
            <li>Aantal personen: <strong>4</strong></li>
            <li>Aantal slaapkamers: <strong>3 </strong></li>
            <li>Terras</li>
            <li>Gratis wifi</li>
        </ul>
        <a href="bungalows.php">RESERVEER NU</a>
    </div>
    </div>
<div class="item1"><img src="../IMG/bungalow6.jpg">
    <div class="itemtype">
        <p>BASIS</p>
       
    </div>
    <div class= "itemcontent">
     
        <ul>
        <li> PRIJS:<strong>€ 399,-</strong></li>
            <li> PLAATS: <strong>AMSTERDAM</strong></li>
            <li>Aantal personen: <strong>4</strong></li>
            <li>Aantal slaapkamers: <strong>3 </strong></li>
            <li>Terras</li>
            <li>Gratis wifi</li>
        </ul>
        <a href="bungalows.php">RESERVEER NU</a>
    </div>
    </div>
        </div>
   <div class="sectie_1_tekst">
        <p>Verplichte kosten bij de boeking van een verblijf zijn de reserveringskosten (€ 29,50 per boeking), verplicht beddengoed voor Comfort Cottages in Nederland, België en Duitsland (€ 8,95 per persoon), toeristenbelasting en heffingen. De aangegeven prijs is op basis van beschikbaarheid.</p>
       <a href="bungalows.php" class="sectieknopje">Bekijk alle aanbiedingen!</a>
        </div>
    

</div>
<div class="streep">
    
    </div>

 <!--Sectie 2 -->

<div class="sectie_2">

      <div class="sectie_2_inner-width">
        <h1 class="sectie_2_section-title">Onze Bungalows</h1>
        <div class="sectie_2_border"></div>
        <div class="sectie_2_services-container">

          <div class="sectie_2_service-box">
            <div class="sectie_2_service-icon">
<i class="fas fa-wifi"></i>
              </div>
            <div class="sectie_2_service-title">Gratis Wifi</div>
            <div class="sectie_2_service-desc">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et eaque ratione rem porro, nihil.
            </div>
          </div>
            <div class="sectie_2_service-box">
            <div class="sectie_2_service-icon">
<i class="fas fa-home"></i>              </div>
            <div class="sectie_2_service-title">Grote Kamers</div>
            <div class="sectie_2_service-desc">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et eaque ratione rem porro, nihil.
            </div>
          </div>
            <div class="sectie_2_service-box">
            <div class="sectie_2_service-icon">
<i class="fas fa-person-booth"></i>
                </div>
            <div class="sectie_2_service-title">Uitstekende roomservice</div>
            <div class="sectie_2_service-desc">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et eaque ratione rem porro, nihil.
            </div>
          </div>
            <div class="sectie_2_service-box">
            <div class="sectie_2_service-icon">
<i class="fas fa-bed"></i>
                </div>
            <div class="sectie_2_service-title">Zachte comfortabele bedden</div>
            <div class="sectie_2_service-desc">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et eaque ratione rem porro, nihil.
            </div>
          </div>
            <div class="sectie_2_service-box">
            <div class="sectie_2_service-icon">
<i class="fas fa-utensils"></i>
                </div>
            <div class="sectie_2_service-title">Gratis eten</div>
            <div class="sectie_2_service-desc">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et eaque ratione rem porro, nihil.
            </div>
          </div>
            <div class="sectie_2_service-box">
            <div class="sectie_2_service-icon">
<i class="fas fa-couch"></i>
                </div>
            <div class="sectie_2_service-title">Mooi gemeubileerd</div>
            <div class="sectie_2_service-desc">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit. Et eaque ratione rem porro, nihil.
            </div>
          </div>
</div>
        </div>
</div>

 <!--Sectie 3 -->

<div class="sectie_3">
    
<div class="sectie_3_inner">
        <h1>Klant reviews</h1>
        <div class="sectie_3_border"></div>

        <div class="sectie_3_row">
          <div class="sectie_3_col">
            <div class="sectie_3_testimonial">
              <img src="../IMG/p5.jpg" alt="">
              <div class="sectie_3_name">Melissa Rozenburg</div>
              <div class="sectie_3_stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>

              <p>
                "Ieder jaar na carnaval boeken wij een weekend hoog-sauerland. Dit boeken we voor het jaar erna. Vorig jaar betaalden we 389 euro Dit jaar betaalden we maar 317 euro..."
              </p>
            </div>
          </div>

          <div class="sectie_3_col">
            <div class="sectie_3_testimonial">
              <img src="../IMG/p2.png" alt="">
              <div class="sectie_3_name">Amelia De Boer</div>
              <div class="sectie_3_stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>

              <p>
                "Hert park is werkelijk prachtig! Voor kinderen is er ontzettend veel animatie. Mooi schoon zwembad. Lekker eten in het restaurant. Super vriendelijk personeel!! Top"
              </p>
            </div>
          </div>
            <div class="sectie_3_col">
            <div class="sectie_3_testimonial">
              <img src="../IMG/p7.jpg" alt="">
              <div class="sectie_3_name">Moreno Havertong</div>
              <div class="sectie_3_stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>

              <p>
               "Wederom een midweek bij de katjeskelder geweest. Ondanks het slechte weer toch weer genoten van het prima ingerichte verblijf en de fijne wandelingen door het bos. "
              </p>
            </div>
          </div>
    </div>
    </div>
</div>

<?php include 'footer.php'?>